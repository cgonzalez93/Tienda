﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TecnoShop.Model.Entities;

namespace TecnoShop.Model.Repository.Impl
{
    public class UserRepository : IUserRepository
    {
        public User FindUser(string userName, string password)
        {
            User user = null;
            if (string.IsNullOrEmpty(userName)) throw new ArgumentException("username is required");
            if (string.IsNullOrEmpty(password)) throw new ArgumentException("password is required");

            if(userName.Equals("admin") && password.Equals("123"))
            {
                user = new User() 
                {
                    UserName="admin",
                    FirstName="Ronald",
                    SurName="E",
                    LastName="Cuello",
                    Identification="789654123000"

                };
                
            }

            return user;
        }
    }
}
